let jsonData = [];

document.getElementById("fileInput").addEventListener("change", function (event) {
  const file = event.target.files[0];
  const reader = new FileReader();
  reader.onload = function (e) {
    try {
      const data = JSON.parse(e.target.result);
      processData(data);
    } catch (error) {
      alert("Invalid JSON file");
    }
  };
  reader.readAsText(file);
});

function loadFromText() {
  try {
    const text = document.getElementById("jsonInput").value;
    const data = JSON.parse(text);
    processData(data);
  } catch (error) {
    alert("Invalid JSON text");
  }
}

function processData(data) {
  jsonData = Array.isArray(data) ? data : data.data || [];
  if (!Array.isArray(jsonData)) {
    alert("JSON format not supported.");
    return;
  }

  const container = document.getElementById("tableContainer");
  container.innerHTML = "";
  if (jsonData.length === 0) return;

  const table = document.createElement("table");
  const header = table.insertRow();
  Object.keys(jsonData[0]).forEach((key) => {
    const th = document.createElement("th");
    th.textContent = key;
    header.appendChild(th);
  });

  jsonData.forEach((item) => {
    const row = table.insertRow();
    Object.values(item).forEach((val) => {
      const cell = row.insertCell();
      cell.textContent = val;
    });
  });

  container.appendChild(table);
  document.getElementById("downloadBtn").disabled = false;
}

function downloadExcel() {
  let csv = "";
  const headers = Object.keys(jsonData[0]);
  csv += headers.join(",") + "\n";

  jsonData.forEach((row) => {
    csv += headers.map((key) => JSON.stringify(row[key] ?? "")).join(",") + "\n";
  });

  const blob = new Blob([csv], { type: "text/csv" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "data.csv";
  link.click();
}
